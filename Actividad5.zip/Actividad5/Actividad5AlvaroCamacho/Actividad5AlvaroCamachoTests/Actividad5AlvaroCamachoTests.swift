//
//  Actividad5AlvaroCamachoTests.swift
//  Actividad5AlvaroCamachoTests
//
//  Created by Alvaro Camacho on 3/2/25.
//

import Testing
@testable import Actividad5AlvaroCamacho

struct Actividad5AlvaroCamachoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
