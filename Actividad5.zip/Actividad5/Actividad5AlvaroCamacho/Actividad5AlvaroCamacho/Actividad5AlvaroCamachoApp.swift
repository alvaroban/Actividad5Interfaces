//
//  Actividad5AlvaroCamachoApp.swift
//  Actividad5AlvaroCamacho
//
//  Created by Alvaro Camacho on 3/2/25.
//

import SwiftUI

@main
struct Actividad5AlvaroCamachoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
