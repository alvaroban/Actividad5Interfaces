//
//  MovieDetailView.swift
//  Actividad5AlvaroCamacho
//
//  Created by Alvaro Camacho on 4/2/25.
//

import SwiftUI

struct MovieDetailView: View {
    
    let movie: ApiNetwork.Movie
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

/*#Preview {
    MovieDetailView(movie: <#T##ApiNetwork.Movie#>)
}*/
